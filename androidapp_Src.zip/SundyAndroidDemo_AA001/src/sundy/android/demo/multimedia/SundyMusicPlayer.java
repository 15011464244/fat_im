package sundy.android.demo.multimedia;

import android.app.ListActivity;
import android.os.Bundle;

public class SundyMusicPlayer extends ListActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}

}
