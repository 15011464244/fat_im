package sundy.android.demo.configration;

public class CommonConstants {
	/**Application  -- "SundyAndroidDemoApplication" */
	public static final String LOGCAT_APP_NAME = "SundyAndroidDemoApplication"  ;
	/**        */
	public static final String MAIN_LIST_VIEW_ITEMNAME = "sundy.android.demo" ;
	/**Activity -- "SundyAndroidDemoLog" */
	public static final String LOGCAT_TAG_NAME = "SundyAndroidDemoLog"  ;
	/**app name define*/
	public static final String APP_PACKAGE_NAME = "sundy.android.demo" ;
	public static final String CATEGORY_SAMPLE_CODE = "sundy.android.sample_code" ;
}
