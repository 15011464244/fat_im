package sundy.android.demo.uiadv.style;

import sundy.android.demo.R;

import android.app.Activity;
import android.os.Bundle;

public class BubbleThemeActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

}
