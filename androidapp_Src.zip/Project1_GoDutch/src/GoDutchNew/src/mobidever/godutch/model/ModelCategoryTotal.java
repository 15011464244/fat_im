package mobidever.godutch.model;

import java.io.Serializable;

public class ModelCategoryTotal implements Serializable {
	public String Count;
	public String SumAmount;
	public String CategoryName;
}
